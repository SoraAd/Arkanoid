using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuPause : MonoBehaviour
{
    public static MenuPause instance;
    [SerializeField] private GameObject _pauseCanvas;
    [SerializeField] private GameObject _informationCanvas;
    private Boolean pauseGame = false;
    
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape) && !pauseGame)
        {
            Time.timeScale = 0f;
            _pauseCanvas.SetActive(true);
            _informationCanvas.SetActive(false);
            pauseGame = true;
            return;
        }

        if(Input.GetKeyDown(KeyCode.Escape) && pauseGame)
        {
            Time.timeScale = 1f;
            _pauseCanvas.SetActive(false);
            _informationCanvas.SetActive(true);
            pauseGame = false;
            return;
        }
    }

    public void QuitPause()
    {
        
        Time.timeScale = 1f;
        _pauseCanvas.SetActive(false);
        _informationCanvas.SetActive(true);
    }

    public void ExitGame()
    {
        
        Application.Quit();
    }
}
