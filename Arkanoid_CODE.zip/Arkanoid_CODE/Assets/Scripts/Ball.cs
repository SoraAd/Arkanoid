using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Scripting.APIUpdating;

public class Ball : MonoBehaviour
{
    public static Ball ballInstance;
    [SerializeField] private Vector2 initialVelocity;
    [SerializeField] private float velocityMultiplier = 1.05f;
    [SerializeField] private GameObject parentPlane;
    public static Ball ball;
    private Rigidbody2D ballRb;
    private bool isBallMoving;
    private Vector2 locationInit;
    private Vector2 positionInit;

     private void Awake()
    {
        if(ballInstance == null)
        {
            ballInstance = this;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        ballRb = GetComponent<Rigidbody2D>();
        locationInit = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        Launch();
    }

    
    private void Launch(){
        if(Input.GetKeyDown(KeyCode.Space) && !isBallMoving)
        {
            transform.parent = null;
            positionInit = ballRb.position;
            ballRb.velocity = initialVelocity;
            isBallMoving = true;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        
        if(collision.gameObject.CompareTag("Block"))
        {
            Destroy(collision.gameObject);
            GameManager.instance.BlockDestroyed();
            Sounds.instance.hitBlock();
        }
        VelocityFix();
    }

    private void VelocityFix()
    {
        float velocityDelta = 1.1f;
        float minVelocity = 0.5f;

        if(Mathf.Abs(ballRb.velocity.x) < minVelocity)
        {
            velocityDelta = Random.value < 0.5f ? velocityDelta : -velocityDelta;
            ballRb.velocity += new Vector2(velocityDelta,0f);
        }

        if(Mathf.Abs(ballRb.velocity.y) < minVelocity)
        {
            velocityDelta = Random.value < 0.5f ? velocityDelta : -velocityDelta;
            ballRb.velocity += new Vector2(0f,velocityDelta);
        }
    }

    public void upDificulty()
    {
        ballRb.velocity *= velocityMultiplier;
        ballRb.position = positionInit;
    }

    public void restarBall()
    {
        transform.position = locationInit;
        ballRb.velocity = -ballRb.velocity;
    }
}
