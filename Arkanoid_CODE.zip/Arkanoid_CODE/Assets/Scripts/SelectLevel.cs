using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class SelectLevel : MonoBehaviour
{

    [SerializeField] private GameObject level1;
    [SerializeField] private GameObject level2;
    [SerializeField] private GameObject level3;
    [SerializeField] private GameObject level4;
    [SerializeField] private GameObject level5;
    public static SelectLevel instance;

     private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    public void SelectLevelRandom()
    {
        
        int level = UnityEngine.Random.Range(1,6);
        ActiveLevel(level);
    }

    private void ActiveLevel(int level)
    {
        Vector3 position = new Vector3(0f,0f);
        GameObject bloc;
        switch(level)
        {
            case 1:
            bloc = Instantiate(level1, position, Quaternion.identity);
            bloc.SetActive(true);
            break;
            case 2:
            bloc = Instantiate(level1, position, Quaternion.identity);
            bloc.SetActive(true);
            break;
            case 3:
            bloc = Instantiate(level1, position, Quaternion.identity);
            bloc.SetActive(true);
            break;
            case 4:
            bloc = Instantiate(level1, position, Quaternion.identity);
            bloc.SetActive(true);
            break;
            case 5:
            bloc = Instantiate(level1, position, Quaternion.identity);
            bloc.SetActive(true);
            break;
        }
    }
}
