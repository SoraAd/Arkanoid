using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Information : MonoBehaviour
{

    public static Information scoreInstance{ get; private set; }
    [SerializeField] private TextMeshProUGUI life;
    [SerializeField] private TextMeshProUGUI score;
    [SerializeField] private TextMeshProUGUI level;
    [SerializeField] private TextMeshProUGUI best;


    private int _score;
    private int getLifeScore = 5000;
    private int lifeBasic = 3;
    private int levelBasic = 1;

    private void Awake()
    {
        if(scoreInstance == null)
        {
            scoreInstance = this;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        score.text = _score.ToString();
        life.text = lifeBasic.ToString();
        level.text = levelBasic.ToString();
        best.text = PlayerPrefs.GetInt("HighScore",0).ToString();
        UpdateBestScore();
    }

    public void UpdateBestScore()
    {
        if(_score > PlayerPrefs.GetInt("HighScore"))
        {
            PlayerPrefs.SetInt("HighScore",_score);
            best.text = _score.ToString();
        }
    }

    // Update is called once per frame
    public void UpdateScore()
    {
        _score += 100;
        score.text = _score.ToString();
        SumLife();
        UpdateBestScore();
    }

    private void SumLife()
    {
        if(_score > getLifeScore)
        {
            lifeBasic++;
            getLifeScore += 5000;
            life.text = lifeBasic.ToString();
        }
    }

    public void RestLife()
    {
        lifeBasic--;
        if(lifeBasic<0)
        {
            SceneManager.LoadScene("GameOver");
            return;
        }
        life.text = lifeBasic.ToString();
        Ball.ballInstance.restarBall();
    }

    public void nextLevel()
    {
        levelBasic++;
        level.text = levelBasic.ToString();
        Ball.ballInstance.upDificulty();
    }
}
