using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sounds : MonoBehaviour
{
    public static Sounds instance;
    public AudioClip hitSound;

    AudioSource audioSource;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        audioSource = GetComponent<AudioSource> ();
    }

    public void hitBlock()
    {
        audioSource.PlayOneShot(hitSound);
    }
}
