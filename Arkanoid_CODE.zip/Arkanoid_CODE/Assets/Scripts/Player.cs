using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] private float moveSpeed;

    private float negativeBoand = 3.25f;
    private float positiveBoand = 7.25f;
   
    // Update is called once per frame
    void Update()
    {
       Mov();
    }

    private void Mov()
    {
        float moveInput = Input.GetAxisRaw("Horizontal");

        Vector2 playerPosition = transform.position;
        playerPosition.x = Mathf.Clamp(playerPosition.x + moveInput * moveSpeed * Time.deltaTime, -negativeBoand, + positiveBoand);
        transform.position = playerPosition;
    }
}
