using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LostLife : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Information.scoreInstance.RestLife();
    }
}
